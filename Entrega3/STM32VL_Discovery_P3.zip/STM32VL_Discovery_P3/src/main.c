/* Standard includes. */
#include <stdint.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"

/* TODO Add any manufacture supplied header files necessary for CMSIS functions
to be available here. */
#include "stm32f10x.h"
#include "STM32vldiscovery.h"

/* Priorities at which the tasks are created.  The event semaphore task is
given the maximum priority of ( configMAX_PRIORITIES - 1 ) to ensure it runs as
soon as the semaphore is given. */
#define mainEVENT_SEMAPHORE_TASK_PRIORITY	( configMAX_PRIORITIES - 1 )
#define DEBOUNCECOUNTS 10
#define mainLED_TASK_PRIORITY			( tskIDLE_PRIORITY )
#define mainButton_TASK_PRIORITY                   ( tskIDLE_PRIORITY + 1 )
#define mainButtonLEDs_TASK_PRIORITY                   ( tskIDLE_PRIORITY )

#define mainQUEUE_LENGTH					( 5 )
#define mainQUEUE_SEND_PERIOD_MS			( 500 / portTICK_RATE_MS )
#define mainQUEUE_RECEIVE_TASK_PRIORITY		( tskIDLE_PRIORITY + 3 )
#define	mainQUEUE_SEND_TASK_PRIORITY2		( tskIDLE_PRIORITY + 2 )
#define	mainQUEUE_SEND_TASK_PRIORITY		( tskIDLE_PRIORITY + 1 )

static void prvSetupHardware( void );

static xSemaphoreHandle xButtonSemaphore = NULL;
static xSemaphoreHandle xUARTSemaphore = NULL;
static xQueueHandle xQueue = NULL;

int x = 0;

uint32_t ulValueToSendUART = 0;

static void prvQueueReceiveTask(void *);
static void prvQueueSendTask(void *);
static void prvQueueSendTaskUART( void *);
void ISQR_Setup(FunctionalState);
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);
void EXTI0_IRQHandler(void);
void USART1_IRQHandler(void);
void USART1_Init(void);


int main(void)
{

	/* Configure the system ready to run the demo.  The clock configuration
	can be done here if it was not done before main() was called. */
	prvSetupHardware();

	STM32vldiscovery_LEDInit(0);

	vSemaphoreCreateBinary(xButtonSemaphore);
	vSemaphoreCreateBinary(xUARTSemaphore);

	vQueueAddToRegistry( xButtonSemaphore, ( signed char * ) "xButtonSemaphore" );
	vQueueAddToRegistry( xUARTSemaphore, ( signed char * ) "xUARTSemaphore" );

	xQueue = xQueueCreate( 	mainQUEUE_LENGTH,		/* The number of items the queue can hold. */
								sizeof( uint32_t ) );	/* The size of each item the queue holds. */

	vQueueAddToRegistry( xQueue, ( signed char * ) "MainQueue" );

	xTaskCreate( 	prvQueueReceiveTask,			/* The function that implements the task. */
						( signed char * ) "Rx", 		/* Text name for the task, just to help debugging. */
						configMINIMAL_STACK_SIZE, 		/* The size (in words) of the stack that should be created for the task. */
						NULL, 							/* A parameter that can be passed into the task.  Not used in this simple demo. */
						mainQUEUE_RECEIVE_TASK_PRIORITY,/* The priority to assign to the task.  tskIDLE_PRIORITY (which is 0) is the lowest priority.  configMAX_PRIORITIES - 1 is the highest priority. */
						NULL );


	xTaskCreate( 	prvQueueSendTask,
						( signed char * ) "TX",
						configMINIMAL_STACK_SIZE,
						NULL,
						mainQUEUE_SEND_TASK_PRIORITY,
						NULL );

	xTaskCreate( 	prvQueueSendTaskUART,
							( signed char * ) "UART",
							configMINIMAL_STACK_SIZE,
							NULL,
							mainQUEUE_SEND_TASK_PRIORITY2,
							NULL );

//	xTaskCreate( vButtonCheckTask, ( signed char * ) "Button", configMINIMAL_STACK_SIZE, NULL, mainButton_TASK_PRIORITY, NULL );
//  	xTaskCreate( vButtonLEDsTask, ( signed char * ) "ButtonLED", configMINIMAL_STACK_SIZE, NULL, mainButtonLEDs_TASK_PRIORITY, NULL );
	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	for( ;; );
}
/*-----------------------------------------------------------*/

static void prvQueueSendTask( void *pvParameters )
{

const uint32_t ulValueToSend = 1;


	for( ;; )
	{
			xSemaphoreTake(xButtonSemaphore,portMAX_DELAY);

			xQueueSend( xQueue, &ulValueToSend, 0 );
			STM32vldiscovery_LEDOn(0);
			vTaskDelay(mainQUEUE_SEND_PERIOD_MS);
			STM32vldiscovery_LEDOff(0);
			//xSemaphoreTake(xButtonSemaphore,0);
			//EXTI_ClearITPendingBit(EXTI_Line0);
			//ISQR_Setup(ENABLE);
			x = !x;
			NVIC_EnableIRQ(EXTI0_IRQn);



	}
}
/*-----------------------------------------------------------*/

static void prvQueueReceiveTask( void *pvParameters )
{
uint32_t ulReceivedValue;


	for( ;; )
	{

		xQueueReceive( xQueue, &ulReceivedValue, portMAX_DELAY );

		if (ulReceivedValue == 1){
			GPIO_WriteBit(GPIOA , GPIO_Pin_1 , !x);

		}

		vTaskDelay(mainQUEUE_SEND_PERIOD_MS);
	}
}
/*-----------------------------------------------------------*/

static void prvQueueSendTaskUART( void *pvParameters )
{



		for( ;; )
		{
				if(xSemaphoreTake(xUARTSemaphore,portMAX_DELAY) == pdTRUE)
				{

				xQueueSend(xQueue, &ulValueToSendUART, 0 );
				STM32vldiscovery_LEDOn(0);
				vTaskDelay(mainQUEUE_SEND_PERIOD_MS);
				STM32vldiscovery_LEDOff(0);
				//xSemaphoreTake(xButtonSemaphore,0);
				//EXTI_ClearITPendingBit(EXTI_Line0);
				//ISQR_Setup(ENABLE);
				x = !x;
				//NVIC_EnableIRQ(EXTI0_IRQn);
				NVIC_EnableIRQ(USART1_IRQn);
				}

		}

}

static void prvSetupHardware( void )
{
	/* Ensure all priority bits are assigned as preemption priority bits.
	http://www.freertos.org/RTOS-Cortex-M3-M4.html */
	NVIC_SetPriorityGrouping( 0 );

	NVIC_Configuration();
	RCC_Configuration();
	GPIO_Configuration();
	USART1_Init();


	/* TODO: Setup the clocks, etc. here, if they were not configured before
	main() was called. */
}

void RCC_Configuration(void)
{
  /* GPIOA and GPIOB clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                         RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);
}

void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_StructInit(&GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA , GPIO_PinSource0);

}

void NVIC_Configuration(void)
{
  EXTI_InitTypeDef EXTI_InitStructure;
  EXTI_InitStructure.EXTI_Line = EXTI_Line0;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);

  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

void USART1_Init(void)
{
    /* USART configuration structure for USART1 */
    USART_InitTypeDef usart1_init_struct;
    /* Bit configuration structure for GPIOA PIN9 and PIN10 */
    GPIO_InitTypeDef gpioa_init_struct;

    /* Enalbe clock for USART1, AFIO and GPIOA */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_AFIO |
                           RCC_APB2Periph_GPIOA, ENABLE);

    /* GPIOA PIN9 alternative function Tx */
    gpioa_init_struct.GPIO_Pin = GPIO_Pin_9;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &gpioa_init_struct);
    /* GPIOA PIN9 alternative function Rx */
    gpioa_init_struct.GPIO_Pin = GPIO_Pin_10;
    gpioa_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
    gpioa_init_struct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpioa_init_struct);

    /* Enable USART1 */
    USART_Cmd(USART1, ENABLE);
    /* Baud rate 9600, 8-bit data, One stop bit
     * No parity, Do both Rx and Tx, No HW flow control
     */
    usart1_init_struct.USART_BaudRate = 9600;
    usart1_init_struct.USART_WordLength = USART_WordLength_8b;
    usart1_init_struct.USART_StopBits = USART_StopBits_1;
    usart1_init_struct.USART_Parity = USART_Parity_No ;
    usart1_init_struct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    usart1_init_struct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    /* Configure USART1 */
    USART_Init(USART1, &usart1_init_struct);
    /* Enable RXNE interrupt */
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    /* Enable USART1 global interrupt */
    NVIC_EnableIRQ(USART1_IRQn);
}

/*void ISQR_Setup(FunctionalState enable){

	  NVIC_InitTypeDef NVIC_InitStructure;
	  NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = enable;
	  NVIC_Init(&NVIC_InitStructure);
}*/

void EXTI0_IRQHandler(void)
{


	//static int count = 0;
	//STM32vldiscovery_LEDOn(0);
	//vTaskDelay(mainQUEUE_SEND_PERIOD_MS);
	//STM32vldiscovery_LEDOff(0);
	//ISQR_Setup(DISABLE);
	//portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)==0)
	{
		NVIC_DisableIRQ(EXTI0_IRQn);
		EXTI_ClearITPendingBit(EXTI_Line0);
		xSemaphoreGiveFromISR(xButtonSemaphore, NULL);
		//vPortYieldFromISR();
	}


	//count++;
}

void USART1_IRQHandler(void)
{

    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {

        if((char)USART_ReceiveData(USART1) == '1')
        	ulValueToSendUART = 1;

        NVIC_DisableIRQ(USART1_IRQn);
        xSemaphoreGiveFromISR(xUARTSemaphore, NULL);
        USART_ClearITPendingBit(USART1,USART_IT_RXNE);
    }

}
